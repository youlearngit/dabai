<?php
/**
 * TODO 基础分页的相同代码封装，使前台的代码更少
 * @param $count 要分页的总记录数
 * @param int $pagesize 每页查询条数
 * @return \Think\Page
 */
function getpage($count, $pagesize = 8) {
    $p = new Think\Page($count, $pagesize);
    $p->setConfig('header', '<li class="rows">共<b>%TOTAL_ROW%</b>条记录&nbsp;第<b>%NOW_PAGE%</b>页/共<b>%TOTAL_PAGE%</b>页</li>');
    $p->setConfig('prev', '上一页');
    $p->setConfig('next', '下一页');
    $p->setConfig('last', '末页');
    $p->setConfig('first', '首页');
    $p->setConfig('theme', '%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%%HEADER%');
    $p->lastSuffix = false;//最后一页不显示为总页数
    return $p;
}

/**
 * 邮件发送函数
 */
     function sendMail($to, $title, $content) {
         $config = C('THINK_EMAIL');
         Vendor('PHPMailer.PHPMailerAutoload');
         $mail = new PHPMailer(); //实例化
         $mail->IsSMTP(); // 启用SMTP
         $mail->Host= $config['SMTP_HOST']; //smtp服务器的名称（这里以QQ邮箱为例）
         $mail->SMTPAuth = true; //启用smtp认证
         //设置使用ssl加密方式登录鉴权
         $mail->SMTPSecure = 'ssl';
         $mail->isHTML(true);
         $mail->Username = $config['FROM_EMAIL']; //你的邮箱名
         $mail->Password = $config['SMTP_PASS'] ; //邮箱密码
         $mail->From = $config['FROM_EMAIL']; //发件人地址（也就是你的邮箱地址）
         $mail->FromName = $config['FROM_NAME']; //发件人姓名
         $mail->Port = $config['SMTP_PORT']; // SMTP服务器的端口号
         $mail->AddAddress($to,"应聘");
         $mail->WordWrap = 50; //设置每行字符长度
         $mail->CharSet= 'UTF-8'; //设置邮件编码
         $mail->Subject =$title; //邮件主题
         $mail->Body = $content; //邮件内容
         //$mail->AltBody = "这是一个纯文本的HTML电子邮件客户端"; //邮件正文不支持HTML的备用显示
         $status = $mail->send();
         if ($status) {
             return true;
         } else {
             return false;
         }

         //return($mail->Send());
     }

?>