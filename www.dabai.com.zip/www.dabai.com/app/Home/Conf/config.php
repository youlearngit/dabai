<?php
return array(
	//'配置项'=>'配置值'
      'layout_on' =>true,//是否开启布局
    'layout_name' =>'foot',
);