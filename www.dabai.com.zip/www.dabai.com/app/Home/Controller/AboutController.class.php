<?php
namespace Home\Controller;
use Think\Controller;
class AboutController extends Controller {
	public function index(){
    	$m=M('article');
        $about=$m->where('catetype=17')->select();
        $lb=$m->where('catetype=6')->select();
        //var_dump($lb);die;
        $this->assign('lb', $lb);
        $this->assign('about', $about);
        $this->display();
    }	
}