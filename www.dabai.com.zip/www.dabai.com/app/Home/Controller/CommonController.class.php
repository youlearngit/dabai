<?php

namespace Home\Controller;
use Think\Controller;
class CommonController extends Controller{
    //put your code here
     public function __construct(){
    	parent::__construct();
        $cate=D('cate');
        $navres=$cate->field('id,name,type')->where(array('parentid'=>0))->select();
        $this->assign('navres', $navres);
    }
}
