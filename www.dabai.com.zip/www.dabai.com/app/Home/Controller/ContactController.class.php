<?php
namespace Home\Controller;
use Think\Controller;
class ContactController extends Controller {
    public function index(){
    	$m=M('article');
        $lb=$m->where('catetype=15')->select();
        //var_dump($lb);die;
        
        $this->assign('lb', $lb);
        $this->display();
    }
   //发送邮件
    public function recruit()
    {
        if(IS_POST){
            //接收表单数据
            $data = I('post.');
            //var_dump($data);die;
            //应聘信息入库
            $res = M('join') -> add($data);
            if($res){
                //发送邮件
                $content = '投递人：'.$data['name']."<br/>".'联系方式：'.$data['number']."<br/>".'应聘职位：'.$data['job']."<br/>".'邮箱：'.$data['email'];
                sendMail('1105211809@qq.com', '应聘信息', $content);
                $this -> success('提交成功！','',true);
            }else{
                $this -> error('提交失败！','',true);
            }
            return;
        }
    }
}