<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	$m=M('article');
        $lb=$m->where('catetype=16')->select();
        $lc=$m->where('catetype=18')->select();
//        var_dump($lc);die;
        $this->assign('lc', $lc);
        $this->assign('lb', $lb);
        $this->display();
    }
}