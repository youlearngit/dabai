<?php
namespace Home\Controller;
use Think\Controller;
class PortfolioController extends Controller {
    public function index(){
    	$m=M('article');
        $lb=$m->where('catetype=9')->select();
        $this->assign('lb', $lb);
        $this->display();
    }
}