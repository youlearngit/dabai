<?php
namespace Home\Controller;
use Think\Controller;
class ServiceController extends Controller {
    public function index(){
    	$m=M('article');
        $hdlist=$m->where('catetype=10')->select();
        $lb=$m->where('catetype=8')->select();
        $this->assign('lb', $lb);
        $this->assign('hdlist', $hdlist);
        $this->display();
    }
}