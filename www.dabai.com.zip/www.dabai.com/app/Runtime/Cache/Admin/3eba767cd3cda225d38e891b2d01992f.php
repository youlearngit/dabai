<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title></title>
		<link rel="stylesheet" type="text/css" href="/Public/Admin/css/public.css" />
		<script type="text/javascript" src="/Public/Admin/js/jquery.min.js"></script>
		<script type="text/javascript" src="/Public/Admin/js/public.js"></script>

		<head></head>

		<body id="bg">
			<!-- 左边节点 -->
			<div class="container">

				<div class="leftsidebar_box">
					<a target="main">
						<div class="line">
							<img src="/Public/Admin/img/coin01.png" />&nbsp;&nbsp;
							<a href="/Admin/Index/index" target="_top">首页</a>
						</div>
					</a>
					<dl class="system_log">
					<dt>
						<img class="icon1" src="/Public/Admin/img/coin03.png" />
						<img class="icon2" src="/Public/Admin/img/coin04.png" />
						 会员管理
						 <img class="icon3" src="/Public/Admin/img/coin19.png" />
						 <img class="icon4" src="/Public/Admin/img/coin20.png" />
					</dt>
						<dd>
							<img class="coin11" src="/Public/Admin/img/coin111.png" /><img class="coin22" src="/Public/Admin/img/coin222.png" />
							<a class="cks" href="/Admin/User/lst" target="main">管理员管理</a><img class="icon5" src="/Public/Admin/img/coin21.png" />
						</dd>
					</dl>
					<dl class="system_log">
						<dt>
					<img class="icon1" src="/Public/Admin/img/coin05.png" /><img class="icon2"
						src="/Public/Admin/img/coin06.png" /> 内容管理<img class="icon3"
						src="/Public/Admin/img/coin19.png" /><img class="icon4"
						src="/Public/Admin/img/coin20.png" />
				</dt>
						<dd>
							<img class="coin11" src="/Public/Admin/img/coin111.png" /><img class="coin22" src="/Public/Admin/img/coin222.png" />
							<a class="cks" href="/Admin/Cate/lst" target="main">栏目管理</a><img class="icon5" src="/Public/Admin/img/coin21.png" />
						</dd>
						<dd>
							<img class="coin11" src="/Public/Admin/img/coin111.png" /><img class="coin22" src="/Public/Admin/img/coin222.png" />
							<a class="cks" href="/Admin/Article/lst" target="main">内容管理</a><img class="icon5" src="/Public/Admin/img/coin21.png" />
						</dd>
					</dl>

					<!--<dl class="system_log">
				<dt>
					<img class="icon1" src="/Public/Admin/img/coinL1.png" /><img class="icon2"
						src="/Public/Admin/img/coinL2.png" /> 系统管理<img class="icon3"
						src="/Public/Admin/img/coin19.png" /><img class="icon4"
						src="/Public/Admin/img/coin20.png" />
				</dt>
				<dd>
					<img class="coin11" src="/Public/Admin/img/coin111.png" /><img class="coin22"
						src="/Public/Admin/img/coin222.png" /><a href="../changepwd.html"
						target="main" class="cks">修改密码</a><img class="icon5"
						src="/Public/Admin/img/coin21.png" />
				</dd>
				<dd>
					<img class="coin11" src="/Public/Admin/img/coin111.png" /><img class="coin22"
						src="/Public/Admin/img/coin222.png" /><a href="<?php echo U('login/logout');?>" target="_top" class="cks">退出</a><img
						class="icon5" src="/Public/Admin/img/coin21.png" />
				</dd>
			</dl>

		</div>-->

				</div>
		</body>

</html>