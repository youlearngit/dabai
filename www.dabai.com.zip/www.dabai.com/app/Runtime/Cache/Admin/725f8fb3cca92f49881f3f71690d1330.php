<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理系统-文章管理</title>
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/css.css" />
<script type="text/javascript" src="/Public/Admin/js/jquery.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js"> </script>
<!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
<!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>

</head>
<body>
	<div id="pageAll">
		<div class="pageTop">
			<div class="page">
				<img src="/Public/Admin/img/coin02.png" /><span><a href="#">首页</a>&nbsp;-&nbsp;<a
					href="#">内容管理</a>&nbsp;-</span>&nbsp;文章管理
			</div>
		</div>
		<div class="page ">
			<!-- 上传广告页面样式 -->
                        <form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo ($artres["id"]); ?>" />
			<div class="">
				
				<div class="baBody">
					<div class="bbD">
			         <th width="120"><i class="require-red"></i>所属分类：</th>
                            <td>
                                <select name="cateid" id="catid" class="required">
                                    <?php if(is_array($cates)): $i = 0; $__LIST__ = $cates;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option <?php if($artres['cateid']==$vo['id']): ?>selected="selected"<?php endif; ?> value="<?php echo ($vo["id"]); ?>"><?php if($vo['parentid'] != 0): ?>|<?php endif; echo str_repeat('-', $vo['level']*8); echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </td>
                        </tr>
					</div>
					<div class="bbD">
					   文章标题：<input type="text" class="input1" name="title" value="<?php echo ($artres["title"]); ?>"/>
					</div>
                                    <div class="bbD">
					   文章作者：<input type="text" class="input1" name="author" value="<?php echo ($artres["author"]); ?>"/>
					</div>
                                    
                                    <div class="bbD">
					   招聘人数：<input type="text" class="input1" name="num" value="<?php echo ($artres["num"]); ?>"/>
					</div>
                                    
                                    <div class="bbD">
                                        
						
						<div class="bbDd">
				<th><i class="require-red"></i>缩略图：</th>
                                <td><input name="pic" id="" type="file">
                                <?php if($artres['pic'] != ''): ?><img src="<?php echo (SITEURL); echo (substr($artres["pic"],2)); ?>" height="50" /><?php else: ?>暂无缩略图<?php endif; ?>
                                </td>
						</div>
					</div>
                              
					<tr>
                                <th>内容：</th>
                                <td><textarea name="content" class="common-textarea" id="content" cols="30" style="width: 98%;" rows="10"><?php echo ($artres["content"]); ?></textarea></td>
                            </tr>
                            </tr>
					
					<div class="bbD">
						<p class="bbDP">
							<button class="btn_ok btn_yes" href="#">提交</button>
							<a class="btn_ok btn_no" href="#">取消</a>
						</p>
					</div>
				</div>
			</div>
                        </form>
			<!-- 上传广告页面样式end -->
		</div>
	</div>

</body>
</html>
<script type="text/javascript">

    //实例化编辑器
   
    UE.getEditor('content',{initialFrameWidth:1500,initialFrameHeight:400,});
    


</script>