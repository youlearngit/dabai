<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>管理系统-栏目管理</title>
		<link rel="stylesheet" type="text/css" href="/Public/Admin/css/css.css" />
		<script type="text/javascript" src="/Public/Admin/js/jquery.min.js"></script>

	</head>

	<body>
		<div id="pageAll">
			<div class="pageTop">
				<div class="page">
					<img src="/Public/Admin/img/coin02.png" /><span><a href="#">首页</a>&nbsp;-&nbsp;<a
					href="#">内容管理</a>&nbsp;-</span>&nbsp;栏目管理
				</div>
			</div>
			<div class="page ">
				<!-- 上传广告页面样式 -->
				<form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
					<div class="">

						<div class="baBody">
							<div class="bbD">
								<th width="120"><i class="require-red"></i>上级分类：</th>
								<td>
									<select name="parentid" id="catid" class="required">
										<option value="0">顶级栏目</option>
										<?php if(is_array($cates)): $i = 0; $__LIST__ = $cates;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>">
												<?php if($vo['parentid'] != 0): ?>|<?php endif; ?>
												<?php echo str_repeat('-', $vo['level']*8); echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
									</select>
								</td>
							</div>
							<div class="bbD">
								栏目名称：<input type="text" class="input1" name="name" />
							</div>
							<div class="bbD">
								<th>栏目类型：</th>
								<td>
									<input class="common-text" name="type" size="50" value="1" checked="checked" type="radio">简介
									<input class="common-text" name="type" size="50" value="2" type="radio">文化
									<input class="common-text" name="type" size="50" value="3" type="radio">案例展示
									<input class="common-text" name="type" size="50" value="4" type="radio">招聘
									<input class="common-text" name="type" size="50" value="5" type="radio">历程

								</td>
							</div>

							<div class="bbD">
								栏目级别：
								<input class="common-text" name="class" size="50" value="1" checked="checked" type="radio">顶级
								<input class="common-text" name="class" size="50" value="2" type="radio">二级
								<input class="common-text" name="class" size="50" value="3" type="radio">三级
							</div>

							<div class="bbD">
								<p class="bbDP">
									<button class="btn_ok btn_yes" href="#">提交</button>
									<a class="btn_ok btn_no" href="#">取消</a>
								</p>
							</div>
						</div>
					</div>
				</form>
				<!-- 上传广告页面样式end -->
			</div>
		</div>

	</body>

</html>