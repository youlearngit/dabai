<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>管理系统-登录</title>
		<link rel="stylesheet" type="text/css" href="/Public/Admin/css/public.css" />
		<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
		<script type="text/javascript" src="/Public/Admin//Public/Admin/js/jquery.min.js"></script>
		<script type="text/javascript" src="/Public/Admin//Public/Admin/js/public.js"></script>
	</head>

	<body>

		<!-- 登录页面头部 -->
		<div class="logHead">
			<img src="/Public/Admin/img/logLOGO.png" />
		</div>
		<!-- 登录页面头部结束 -->

		<!-- 登录body -->
		<form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
			<div class="logDiv">
				<img class="logBanner" src="/Public/Admin/img/logBanner.png" />
				<div class="logGet">
					<!-- 头部提示信息 -->
					<div class="logD logDtip">
						<p class="p1">登&nbsp;录</p>
						<p class="p2">大白网络</p>
					</div>
					<!-- 输入框 -->
					<div class="lgD">
						<img class="img1" src="/Public/Admin/img/logName.png" /><input type="text" placeholder="输入用户名" id="usertxt" name="username" />
					</div>
					<div class="lgD">
						<img class="img1" src="/Public/Admin/img/logPwd.png" /><input type="password" placeholder="输入用户密码" id="pwdtxt" name="pwd" />
					</div>
					<!--<div class="lgD logD2">
				<input class="getYZM" type="text" />
				<div class="logYZM">
					<img class="yzm" src="/Public/Admin/img/logYZM.png" />
				</div>
			</div>-->
					<div class="logC">
						<input type="submit" tabindex="3" value="登录" class="btn btn-lg btn-block" style=" background-color: #DD9900; color: white;border-radius: 5px;height: 50px;width: 100%;" />
					</div>
				</div>
			</div>

			<!-- 登录body  end -->
		</form>
		<!-- 登录页面底部 -->
		<div class="logFoot">
			<p class="p1">芜湖大白网络有限公司</p>
		</div>

	</body>

</html>