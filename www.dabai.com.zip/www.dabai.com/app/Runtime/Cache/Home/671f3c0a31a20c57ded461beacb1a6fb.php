<?php if (!defined('THINK_PATH')) exit();?>















<!DOCTYPE HTML>
<html>
<head>
<title>大白网络</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="大白、安徽大白、大白芜湖、 大白网络、大白科技、">
<link rel="icon" href="/Public/Home/images/dabai.ico" mce_href="/Public/Home/images/dabai.ico" type="image/x-icon">
<!-- font files -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
<!--<link rel="stylesheet" href="/Public/Home/css/templatemo-style.css" />-->
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!-- /font files -->
<!-- css files -->
<link rel="stylesheet" href="/Public/Home/css/wbstyle.css" />
<link href="/Public/Home/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/info.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all" />

<!-- /css files -->
</head>
	<body>
		<!-- 导航栏 -->
		<div class="navbar-wrapper">
			<div class="container">
				<nav class="navbar navbar-inverse navbar-static-top cl-effect-5">
					<div class="container">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.html"><h1>大白网络</h1></a>
						</div>
						<div id="navbar" class="navbar-collapse collapse" >
							<ul class="nav navbar-nav navbar-right" style="font-size: 20px;">
								<li class="active"><a href="index.html"><span data-hover="首页">首页</span></a></li>
								<li><a href="about.html"><span data-hover="公司介绍">公司介绍</span></a><span class="line1">/<span></li>
						        <li><a href="service.html"><span data-hover="企业文化">企业文化</span></a><span class="line1">/<span></li>
						        <li><a href="portfolio.html"><span data-hover="优秀案例">优秀案例</span></a><span class="line1">/<span></li>
						        <li><a href="contact.html"><span data-hover="诚聘英才">诚聘英才</span></a><span class="line1">/<span></li>
						 
							</ul>
						</div>
					</div>
		        </nav>
			</div>
		</div>

		<!-- 轮播图  -->		              
		<div class="slider">
			<ul class="slider-main">
				<?php if(is_array($lb)): $i = 0; $__LIST__ = $lb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="slider-panel"> 
					<img alt="W3layouts" title="W3layouts" src="<?php echo ($vo["pic"]); ?>">
					<div class="banner-info">
						<!--<div class="row">
							<div class="col-lg-6 banner-w3ls1">
								<h3>芜湖大白网络</h3>
							</div>
							<div class="col-lg-6 banner-w3ls2">	
								<p>一个梦想起飞的地方</p >						
							</div>
						</div>	-->
					</div>
				</li><?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			
		</div>
		<!-- 我们的服务  -->
		<section class="focus">
			<h3 class="text-center">我们的服务 </h3>
			<p class="text-center">为用户服务、对用户负责、让用户满意</p>
			<div class="container">
				<div class="row">
                                    <?php if(is_array($lc)): $i = 0; $__LIST__ = $lc;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="col-lg-3 col-md-3 col-sm-6 focus-w3ls">
						<div class="focus-w3layouts1">
                                                    <i class="<?php if($v[id] == 45): ?>fa fa-university<?php elseif($v[id] == 46): ?>fa fa-cogs<?php elseif($v[id] == 47): ?>fa fa-cubes<?php else: ?>fa fa-money<?php endif; ?>" aria-hidden="true"></i>
							<h4><?php echo ($v["title"]); ?></h4>
							<p class="focus-agile"><?php echo (htmlspecialchars_decode($v["content"])); ?></p>
						</div>
					</div><?php endforeach; endif; else: echo "" ;endif; ?>
					
					
					
				</div>
			</div>
			
			
			
		</section>
        <!--大白语录-->
		<section class="divider">
			<div class="container">
				<blockquote>
					时光荏苒，大白网络已经三岁啦~在这三年的时间里，大白网络和大家一起成长，一起进步，
					感谢这一路走来有大家的陪伴！在接下来的日子里，希望大家能够继续陪伴,
		                      一起努力，和大白网络携手走向更好的明天！
				</blockquote>
				<h3>大白网络 </h3>
			</div>
		</section>

        <!--  案例展示 -->
		<section class="our-blog">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-6 blog-w3ls1">
						<h3 style="color: #000000;"> 案例展示 </h3>
						<p style="color: #000000;" class="blog-p1">大白网络自2015年创立以来，公司团队先后成功运营多家知名芜湖微信公众号，多次策划大型活动，为打造芜湖都市生活第一指南而努力！</p>	
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 blog-w3ls2">
						<div class="blog-agile">
							<a href="#" class="blogimg-w3ls">
								<div class="hover01 column">
									<div>
										<figure><img src="/Public/Home/images/indexa (1).jpg" alt="芜湖派" class="img-responsive"></figure>
									</div>
								</div>
							</a>		
							<a href="#" class="blogimg-w3lh"><h4> 芜湖派 </h4></a>
							<p class="blog-p2">关于芜湖吃喝玩乐购学指南，突发事件，新鲜事爆料，做芜湖有态度的自媒体！</p>
							<!--<a href="#" class="blogimg-agile"> 
								<p> 了解更多 </p>	
								<span class="fa fa-angle-double-right" aria-hidden="true"></span>
											</a>-->
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-6 blog-w3ls2">
								<div class="blog-agile">
									<a href="#" class="blogimg-w3ls">
										<div class="hover01 column">
											<div>
												<figure><img src="/Public/Home/images/indexa (2).jpg" alt="吃遍芜湖" class="img-responsive"></figure>
											</div>
										</div>
									</a>
									<a href="#" class="blogimg-w3lh">
										<h4> 逛吃逛吃 </h4></a>
									<p class="blog-p2">大白网络倾力打造的全新美食发现栏目，看美女主播带你逛遍芜湖美食！</p>
									<!--<a href="#" class="blogimg-agile">
										<p> 了解更多 </p>
										<span class="fa fa-angle-double-right" aria-hidden="true"></span>
									</a>-->
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-6 blog-w3ls2">
								<div class="blog-agile">
									<a href="#" class="blogimg-w3ls">
										<div class="hover01 column">
											<div>
												<figure><img src="/Public/Home/images/indexa (3).jpg" alt="芜湖购" class="img-responsive"></figure>
											</div>
										</div>
									</a>
									<a href="#" class="blogimg-w3lh">
										<h4> 芜湖购 </h4></a>
									<p class="blog-p2">精选芜湖地区吃喝玩乐、旅游美食、优惠打折信息,吃喝玩乐在芜湖，生活不将就！</p>
									<!--<a href="#" class="blogimg-agile">
										<p> 了解更多 </p>
										<span class="fa fa-angle-double-right" aria-hidden="true"></span>
									</a>-->
								</div>
							</div>
					</div>
				</div>
		</section>

<!-- footer -->


<!-- footer -->
<!-- js files -->
<script src="/Public/Home/js/jquery.min.js"></script>
<!--<script type="text/javascript" src="/Public/Home/js/typed.js" ></script>-->
<!--<script type="text/javascript" src="/Public/Home/js/custom.js" ></script>-->
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/SmoothScroll.min.js"></script>
<!-- js for team section -->
<script src="/Public/Home/js/index.js"></script>
<!-- /js for team section -->
<!-- js for banner -->
<script type="text/javascript" src="/Public/Home/js/zslider-1.0.1.js"></script>
<script type="text/javascript">
		var slider = $('.slider').zslider({
			imagePanels: $('.slider-panel'),
			ctrlItems: $('.slider-item'),
			ctrlItemHoverCls: 'slider-item-selected',
			//panelHoverShowFlipBtn: false,
			flipBtn: {
				container: $('.slider-page'),
				preBtn: $('.slider-pre'), 
				nextBtn: $('.slider-next')
			},
			callbacks: {
				animate: function(imagePanels, ctrlItems, fromIndex, toIndex) {
					return true;
				}
			}
		});
</script>

</body>
</html>
<!-- footer -->

	 <div class="footer">
			<div class="wrap" >
			
				<div class="footer-grid footer-grid2" >
					<h4 style="line-height:0.7em">联系我们</h4>
				    <ul>
						<li style="height:1em;">
							<i class="pin"> </i>
						
							<div class="extra-wrap">
								<p style="font-size:13.5px;color:#999999"> 安徽省 芜湖市 镜湖区 世茂滨江写字楼 25楼 2512室</p >
                                                                
							</div>
						</li>
						<li style="height:1em ;"><i class="phone" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">Tel:&nbsp;&nbsp;0553-3938868</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="mail"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="earth"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
                                                <li style="height:1em ;"><i class="" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">版权所有&nbsp;©&nbsp;芜湖大白网络技术有限公司&nbsp;&nbsp;&nbsp;皖ICP备18012127号&nbsp;</p >
						</div></li>
					</ul>
				</div>
			
				<div class=" footer-grid4">
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
		
				<div class="footer-grid4" >
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
				<div class="clear"> </div>
			</div>
		</div>

<!-- footer -->