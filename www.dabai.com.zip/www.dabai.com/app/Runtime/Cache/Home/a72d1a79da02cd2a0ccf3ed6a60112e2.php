<?php if (!defined('THINK_PATH')) exit();?>















<!DOCTYPE HTML>
<html>
<head>
<title>Portfolio</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<!-- font files -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!-- /font files -->
<!-- css files -->
<link href="/Public/Home/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/typo.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/info.css" rel="stylesheet" type="text/css" media="all" />
<link href="/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="/Public/Home/css/wbstyle.css" />
<!-- /css files -->
</head>
<body>
<!-- navigation -->
<div class="navbar-wrapper">
    <div class="container">
		<nav class="navbar navbar-inverse navbar-static-top cl-effect-5">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">大白网络</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><h1>大白网络</h1></a>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="index.html"><span data-hover="首页">首页</span></a></li>
						<li><a href="about.html"><span data-hover="公司简介">公司简介</span></a><span class="line1">/<span></li>
						<li><a href="service.html"><span data-hover="企业文化">企业文化</span></a><span class="line1">/<span></li>
						<li class="active"><a href="portfolio.html"><span data-hover="优秀案例">优秀案例</span></a><span class="line1">/<span></li>
						<li><a href="contact.html"><span data-hover="诚聘英才">诚聘英才</span></a><span class="line1">/<span></li>
					</ul>
				</div>
			</div>
        </nav>
	</div>
</div>
<!-- /navigation -->
<!-- banner section -->
<section class="innerpage-banner">

</section>
<!-- /banner section -->
<section class="innerpage-header">
    <div class="container">
		<!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12"> 
				<h2 class="page-header text-center">优秀案例</h2> 
            </div>
        </div>
        <!-- /.row -->
	</div>
</section>
 <!-- Page Content -->
<section class="portfolio-w3ls"> 
	<div class="container">
        <!-- Project One -->
        <?php if(is_array($lb)): $i = 0; $__LIST__ = $lb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="row">
            <div class="col-md-7">
                <a href="portfolio-item.html">
					<div class="hover01 column">
						<div>
							<figure>
								<img class="img-responsive img-hover" src="<?php echo ($v["pic"]); ?>" alt="芜湖派" title="芜湖派">
							</figure>
						</div>
					</div>		
				</a>
            </div>
            <div class="col-md-5">
                <h3><?php echo ($v["title"]); ?></h3>
                <p><?php echo (htmlspecialchars_decode($v["content"])); ?></p>
               
            </div>
        </div>
            </br><?php endforeach; endif; else: echo "" ;endif; ?>
	</div>
</section>

<!-- footer -->

<!-- js files -->
<script src="/Public/Home/js/jquery.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/SmoothScroll.min.js"></script>
<!-- js for team section -->
<script src="/Public/Home/js/index.js"></script>
<!-- /js for team section -->
<!-- js for banner -->
<script type="text/javascript" src="/Public/Home/js/zslider-1.0.1.js"></script>
<script type="text/javascript">
		var slider = $('.slider').zslider({
			imagePanels: $('.slider-panel'),
			ctrlItems: $('.slider-item'),
			ctrlItemHoverCls: 'slider-item-selected',
			//panelHoverShowFlipBtn: false,
			flipBtn: {
				container: $('.slider-page'),
				preBtn: $('.slider-pre'), 
				nextBtn: $('.slider-next')
			},
			callbacks: {
				animate: function(imagePanels, ctrlItems, fromIndex, toIndex) {
					return true;
				}
			}
		});
</script>
<!-- /js for banner -->
<!-- /js files -->
</body>
</html>
<!-- footer -->

	 <div class="footer">
			<div class="wrap" >
			
				<div class="footer-grid footer-grid2" >
					<h4 style="line-height:0.7em">联系我们</h4>
				    <ul>
						<li style="height:1em;">
							<i class="pin"> </i>
						
							<div class="extra-wrap">
								<p style="font-size:13.5px;color:#999999"> 安徽省 芜湖市 镜湖区 世茂滨江写字楼 25楼 2512室</p >
                                                                
							</div>
						</li>
						<li style="height:1em ;"><i class="phone" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">Tel:&nbsp;&nbsp;0553-3938868</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="mail"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="earth"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
                                                <li style="height:1em ;"><i class="" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">版权所有&nbsp;©&nbsp;芜湖大白网络技术有限公司&nbsp;&nbsp;&nbsp;皖ICP备18012127号&nbsp;</p >
						</div></li>
					</ul>
				</div>
			
				<div class=" footer-grid4">
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
		
				<div class="footer-grid4" >
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
				<div class="clear"> </div>
			</div>
		</div>

<!-- footer -->