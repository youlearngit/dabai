<?php if (!defined('THINK_PATH')) exit();?>















<!DOCTYPE HTML>
<html>

	<head>
		<title>关于我们</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<!-- font files -->
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css" media="all" rel="stylesheet" type="text/css">
		<link href='https://fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
		<!-- /font files -->
		<!-- css files -->
		<link href="/Public/Home/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
		<link href="/Public/Home/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
		<link href="/Public/Home/css/typo.css" rel="stylesheet" type="text/css" media="all" />
		<link href="/Public/Home/css/info.css" rel="stylesheet" type="text/css" media="all" />
		<link href="/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link rel="stylesheet" href="/Public/Home/css/wbstyle.css" />

		<!--引入团队建设js与css-->
		<link href="/Public/Home/css/styles.css" rel="stylesheet">

		<!-- Load jQuery -->
		<script type="text/javascript" src="/Public/Home/js/jquery.min.js"></script>

		<!-- 必要样式 -->
		<link href="/Public/Home/css/mislider.css" rel="stylesheet">
		<link href="/Public/Home/css/mislider-skin-cameo.css" rel="stylesheet">

		<script type="text/javascript" src="/Public/Home/js/mislider.js"></script>
		<script type="text/javascript">
			jQuery(function($) {
				var slider = $('.mis-stage').miSlider({
					//  The height of the stage in px. Options: false or positive integer. false = height is calculated using maximum slide heights. Default: false
					stageHeight: 380,
					//  Number of slides visible at one time. Options: false or positive integer. false = Fit as many as possible.  Default: 1
					slidesOnStage: false,
					//  The location of the current slide on the stage. Options: 'left', 'right', 'center'. Defualt: 'left'
					slidePosition: 'center',
					//  The slide to start on. Options: 'beg', 'mid', 'end' or slide number starting at 1 - '1','2','3', etc. Defualt: 'beg'
					slideStart: 'mid',
					//  The relative percentage scaling factor of the current slide - other slides are scaled down. Options: positive number 100 or higher. 100 = No scaling. Defualt: 100
					slideScaling: 150,
					//  The vertical offset of the slide center as a percentage of slide height. Options:  positive or negative number. Neg value = up. Pos value = down. 0 = No offset. Default: 0
					offsetV: -5,
					//  Center slide contents vertically - Boolean. Default: false
					centerV: true,
					//  Opacity of the prev and next button navigation when not transitioning. Options: Number between 0 and 1. 0 (transparent) - 1 (opaque). Default: .5
					navButtonsOpacity: 1
				});
			});
		</script>

	</head>

	<body>
		<!-- navigation -->
		<div class="navbar-wrapper">
			<div class="container">
				<nav class="navbar navbar-inverse navbar-static-top cl-effect-5">
					<div class="container">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
							<a class="navbar-brand" href="index.html">
								<h1>大白网络</h1></a>
						</div>
						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.html"><span data-hover="首页">首页</span></a>
								</li>
								<li class="active">
									<a href="about.html"><span data-hover="公司简介">公司简介</span></a><span class="line1"></span></li>
								<li>
									<a href="service.html"><span data-hover="企业文化">企业文化</span></a><span class="line1">/<span></li>
								<li><a href="portfolio.html"><span data-hover="优秀案例">优秀案例</span></a><span class="line1">/<span></li>
								<li><a href="contact.html"><span data-hover="人员招聘">人员招聘</span></a><span class="line1">/<span></li>
							</ul>
					</div>
			</div>
        </nav>
	</div>
</div>
<!-- /navigation -->
<!-- banner section -->
<section class="innerpage-banner">
</section>
<!-- /banner section -->
<!-- Page headers -->
<section class="innerpage-header">
    <div class="container">
		<!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                
				<h2 class="page-header text-center">公司简介</h2>
            </div>
        </div>
        <!-- /.row -->
	</div>
</section>
<section class="about-intro">	
<?php if(is_array($about)): $i = 0; $__LIST__ = $about;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="container">
        <!-- Intro Content -->
        <div class="row">
            <div class="col-md-6">
				<div class="hover01 column">
					<div>
						<figure>
							<img class="img-responsive" src="<?php echo ($vo["pic"]); ?>" alt="公司简介" title="w3layouts">
						</figure>
					</div>
				</div>
            </div>
            <div class="col-md-6">
                <h3>芜湖大白公司</h3>
                <p><?php echo (htmlspecialchars_decode($vo["content"])); ?></p>
            </div>
        </div>
        <!-- /.row -->
	</div><?php endforeach; endif; else: echo "" ;endif; ?>
</section>	
<!-- divider section -->
<section class="divider">
	<div class="container">
		<blockquote>
		"以新媒体平台为载体，搭载微信、微博、qq等自媒体平台形成流量矩阵，逐步在各自媒体平台发展、壮大，形成付费内容、游戏、小程序等多种全新移动互联网商业模式 "
		</blockquote>
		<h3>大白欢迎你</h3>
	</div>
</section>
<!-- /divider section -->
<!-- Team Members -->
<section class="about-team">
	<h3 class="text-center">团队建设</h3>
	<p class="text-center">部门分工及团队建设</p>
	<div class="container">	
        <div class="row">
    
         		
         
         <div class="col-md-12" style="margin-top:100px; ">
    					
    				<?php if(is_array($lb)): $i = 0; $__LIST__ = $lb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="col-md-12" style="margin-top:100px; ">
                                    <div class="col-md-6" style="float:<?php if(($v[id]%2==0)): ?>right<?php else: ?>left<?php endif; ?>;text-align: center;border-left:<?php if(($v[id]%2==0)): ?>5px solid #777777<?php endif; ?>;">
    					<h3 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span style="color: #269ABC;"><?php echo ($v["title"]); ?></span></h3>
    					</div>
    					<div class="col-md-6" style="float:<?php if(($v[id]%2==0)): ?>left<?php else: ?>right<?php endif; ?>;padding-top:10px; padding-right: 50px;border-left:<?php if(($v[id]%2==1)): ?>5px solid #777777<?php endif; ?>;  ">
    						
							<p><?php echo (htmlspecialchars_decode($v["content"])); ?></p>
    					</div>
    					
    				</div>
    				<div style="clear: both;"></div><?php endforeach; endif; else: echo "" ;endif; ?>
        <!-- /.row -->
	</div>
    				
    				
    				
	</div>
</section>	
<!-- team section -->



<!-- js files -->
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/SmoothScroll.min.js"></script>
<!-- js for banner -->
<script type="text/javascript" src="/Public/Home/js/zslider-1.0.1.js"></script>
<script type="text/javascript">
		var slider = $('.slider').zslider({
			imagePanels: $('.slider-panel'),
			ctrlItems: $('.slider-item'),
			ctrlItemHoverCls: 'slider-item-selected',
			//panelHoverShowFlipBtn: false,
			flipBtn: {
				container: $('.slider-page'),
				preBtn: $('.slider-pre'), 
				nextBtn: $('.slider-next')
			},
			callbacks: {
				animate: function(imagePanels, ctrlItems, fromIndex, toIndex) {
					return true;
				}
			}
		});
</script>
<!-- /js for banner -->
<!-- /js files -->
</body>
</html>
<!-- footer -->

	 <div class="footer">
			<div class="wrap" >
			
				<div class="footer-grid footer-grid2" >
					<h4 style="line-height:0.7em">联系我们</h4>
				    <ul>
						<li style="height:1em;">
							<i class="pin"> </i>
						
							<div class="extra-wrap">
								<p style="font-size:13.5px;color:#999999"> 安徽省 芜湖市 镜湖区 世茂滨江写字楼 25楼 2512室</p >
                                                                
							</div>
						</li>
						<li style="height:1em ;"><i class="phone" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">Tel:&nbsp;&nbsp;0553-3938868</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="mail"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
						<li style="height:1em;text-align: left;"><i class="earth"> </i><div class="extra-wrap1">
							<p style="font-size:13.5px;color:#999999">Email:&nbsp;&nbsp;1105211809@qq.com</p >
						</div></li>
                                                <li style="height:1em ;"><i class="" style=" text-align: left;"> </i><div class="extra-wrap">
							<p style="font-size:13.5px;color:#999999">版权所有&nbsp;©&nbsp;芜湖大白网络技术有限公司&nbsp;&nbsp;&nbsp;皖ICP备18012127号&nbsp;</p >
						</div></li>
					</ul>
				</div>
			
				<div class=" footer-grid4">
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
		
				<div class="footer-grid4" >
				
				<div style="float: left;">
					<img src="/Public/Home/images/11.jpg" width="80%"/>
					<p style="color:#999999">芜湖购</p>
				</div>
				
				</div>
				<div class="clear"> </div>
			</div>
		</div>

<!-- footer -->